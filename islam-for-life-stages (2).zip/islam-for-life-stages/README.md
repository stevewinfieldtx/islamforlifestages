# Islam for Life Stages

Daily Quranic guidance personalized for your season of life. Stories, poetry, context, and reflections that speak to where you are right now.

## 🌙 Overview

Islam for Life Stages transforms daily Quranic verses into personalized spiritual experiences. Using AI, we generate:

- **Friendly Breakdown**: Conversational exploration of each ayah
- **Modern Stories**: Relatable narratives that bring the Quran to life
- **Poetry**: Inspiring verses in nasheed-inspired styles
- **Deep Context**: Scholarly background (asbab al-nuzul, hadith connections)
- **Prayer Times**: Location-based salah times with notifications
- **Qibla Compass**: Find the direction of the Kaaba

## 🕌 Life Stages

We personalize content for 12 distinct life stages:

| Stage | Description |
|-------|-------------|
| Youth (6-12) | Children learning foundational Islamic concepts |
| Teens (13-17) | Young Muslims navigating identity and faith |
| University (18-24) | College students maintaining faith in secular environments |
| New to Islam | Recent converts learning the basics |
| Newly Married | Couples building their halal home |
| New Parents | Raising righteous children |
| Ramadan Focus | Maximizing the blessed month |
| Hajj/Umrah Prep | Preparing for the journey of a lifetime |
| Empty Nesting | Rediscovering purpose after children leave |
| Divorced | Finding healing through faith |
| Senior (65+) | Preparing for the meeting with Allah |
| Seeking/Questioning | Those exploring Islam |

## 🔧 Tech Stack

- **Framework**: Next.js 16 + React 19
- **Styling**: Tailwind CSS 4 + shadcn/ui
- **AI**: OpenRouter (Claude/GPT) for content generation
- **Images**: Runware for AI-generated imagery
- **Database**: Supabase (auth, caching, profiles)
- **Payments**: Stripe
- **APIs**:
  - Quran.com API (verses, translations)
  - Aladhan API (prayer times, Qibla)

## 🚀 Getting Started

### Prerequisites

- Node.js 18+
- pnpm (recommended) or npm
- Supabase account
- OpenRouter API key
- Stripe account (for payments)

### Environment Variables

Create a `.env.local` file:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

# OpenRouter (AI)
OPENROUTER_API_KEY=your_openrouter_key
OPENROUTER_WRITER_MODEL=anthropic/claude-3-opus
OPENROUTER_RESEARCH_MODEL=openai/gpt-4-turbo-preview

# Runware (Images)
RUNWARE_API_KEY=your_runware_key

# Stripe
STRIPE_SECRET_KEY=your_stripe_secret
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable
```

### Installation

```bash
# Clone the repo
git clone https://github.com/yourusername/islam-for-life-stages.git
cd islam-for-life-stages

# Install dependencies
pnpm install

# Run development server
pnpm dev
```

Visit [http://localhost:3000](http://localhost:3000)

## 📁 Project Structure

```
islam-for-life-stages/
├── app/
│   ├── actions.ts          # AI content generation (Islamic prompts)
│   ├── page.tsx            # Landing page
│   ├── daily/              # Daily ayah page
│   ├── prayer-times/       # Prayer times feature
│   ├── qibla/              # Qibla compass
│   └── example/[verse]/    # Example content preview
├── components/
│   ├── ui/                 # shadcn/ui components
│   ├── PrayerCard.tsx      # Prayer time display
│   └── QiblaCompass.tsx    # Compass UI
├── lib/
│   ├── data/
│   │   ├── life-stages.ts  # 12 Islamic life stages
│   │   └── example-ayahs.ts # Demo verses (Ayat al-Kursi, etc.)
│   ├── types.ts            # TypeScript types
│   ├── quran.ts            # Quran.com API wrapper
│   ├── aladhan.ts          # Prayer times API
│   ├── cache.ts            # Supabase caching
│   └── supabase/           # Database clients
└── public/
    └── images/             # Branding assets
```

## 🎯 Key Features

### Free Tier
- Daily Ayah with Arabic + translation
- Prayer times with notifications
- Qibla compass
- "Let's Talk" AI chat (unlimited)
- Friendly Breakdown (teaser)

### Premium Tier ($4.99/mo or $29.99/yr)
- Full Friendly Breakdown
- Dive Deeper: Context, Stories, Hadith, Poetry
- Ad-free experience

## 🌍 APIs Used

### Quran.com API (Free)
- Verses: `/verses/by_key/{surah}:{ayah}`
- Translations: 100+ languages
- Search: Full-text search
- [Documentation](https://quran.api-docs.io/)

### Aladhan API (Free)
- Prayer Times: `/timings/{timestamp}`
- Qibla Direction: `/qibla/{lat}/{lng}`
- Hijri Calendar: `/gToH/{date}`
- [Documentation](https://aladhan.com/prayer-times-api)

## 🤲 Charity

10% of all profits go to Islamic Relief USA.

## 📜 License

MIT License - see [LICENSE](LICENSE)

## 🙏 Acknowledgments

- Quran.com for the free Quran API
- Aladhan.com for prayer times
- The global Muslim community for feedback and inspiration

---

**Bismillah** - In the name of Allah, the Most Gracious, the Most Merciful.

*Helping Muslims better understand what the Quran means in their season of life.*
